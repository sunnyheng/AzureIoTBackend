# coding: utf-8

# This is interface class which call azure sdk [azure.storage.blob]

# from connction_string import BLOB_CONN_STR

from azure.storage.blob import BlobServiceClient


class AzureStorageBlob(object):
    def __init__(self, conn_str):
        super().__init__()
        self.conn_str = conn_str
        self.client = self.create_client()


    def create_client(self):
        try:
            return BlobServiceClient.from_connection_string(self.conn_str)
        except Exception as e:
            print('Failed to create client:' + str(e))
            return None


    def del_azure_blob(self, id, container_name):
        if not client:
            self.client = BlobServiceClient.from_connection_string(self.conn_str)
        container_client = self.client.get_container_client(container_name)
        try:
            blob_client = container_client.get_blob_client(id)
            blob_client.delete_blob()
            return True
        except Exception as e:
            print('Failed to delete azure blob:' + str(id))
            print('Failed to delete azure blob2:' + str(e))
            return False


    def close_client(self):
        if self.client:
            self.client.close()
