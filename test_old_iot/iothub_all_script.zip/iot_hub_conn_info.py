# coding: utf-8

import pymongo


class IoTHubConnInfo(object):
    def __init__(self, user_id, device_type):
        super().__init__()
        self.user_id = user_id
        self.device_type = device_type
        self.client = None
        self.conn_str = None
        self.record = {}
        self.car_list = []
        self.phone_list = []

    def create_client(self, ip_address, port):
        # self.create_client('127.0.0.1', 27017)
        pass

    def parse_record(self):
        self.set_record()
        self.get_conn_str()
        self.get_phone_list()
        self.get_car_list()

    def get_result_by_user_id(self):
        # result = self.client.getrecord(self.user_id)
        return {"user_id":123456, "car":["car"], "phone":["phone"],
                "hub_conn_str": "HostName=issec-iot.azure-devices.net;SharedAccessKeyName=iothubowner;SharedAccessKey=IzKVWsLMKvNnnOS55NEZZKUHF4TmSx8cOznJtQy7SJI="
                }

    def set_record(self):
        self.record = self.get_result_by_user_id()

    def get_conn_str(self):
        self.conn_str = self.record.get("hub_conn_str")

    def get_car_list(self):
        self.car_list = self.record.get("car")
        return self.car_list

    def get_phone_list(self):
        self.phone_list = self.record.get("phone")
        return self.phone_list

