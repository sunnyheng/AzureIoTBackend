# coding

from connction_string import IOTHUB_PHONE_CONN, PHONE_DEVICE_ID, IOTHUB_CAR_CONN, CAR_DEVICE_ID




class Car(object):
    def __init__(self,conn_str=None, device_id=None):
        super.__init__()
        self.conn_str = conn_str or IOTHUB_CAR_CONN
        self.device_id = device_id or CAR_DEVICE_ID


class Phone(object):
    def __init__(self, conn_str=None, device_id=None):
        super().__init__()
        self.conn_str = conn_str or IOTHUB_PHONE_CONN
        self.device_id = device_id or PHONE_DEVICE_ID