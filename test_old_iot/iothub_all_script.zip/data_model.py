# coding: utf-8

import json



class DataModel(object):
    def __init__(self, operation_type):
        super().__init__()
        self.operationType = operation_type
        self.content = "[]"
        self.deletedId = "[]"

    def set_content(self, data):
        if isinstance(data, list):
            self.content = json.dumps(data)

        if isinstance(data, str):
            self.content = data

    def set_deleted_id(self, deleted_id):
        if isinstance(deleted_id, list):
            self.deleted_id = json.dumps(deleted_id)

        if isinstance(deleted_id, str):
            self.deleted_id = deleted_id

    def __repr__(self):
        if self.content != "[]" and self.deleted_id != "[]":
            return "The operation type: %s, data content: %s, deleted id: %s" %(self.operationType, self.content, self.deletedId)

        elif self.content != "[]":
            return "Not delete message ,the operation type: %s, data content: %s, ." %(self.operationType, self.content)

        else:
            return "Delete message, the operation type: %s, delete id:%s." %(self.operationType, self.deletedId)



# This is function to get c2d feedback message, should define [iothub-ack], full, negotive, positive
# from azure.iot.hub.iothub_http_runtime_manager import IoTHubHttpRuntimeManager
# iothub_http_runtime_manager = IoTHubHttpRuntimeManager.from_connection_string(IOTHUB_PHONE_CONN)
# feedback = iothub_http_runtime_manager.receive_feedback_notification()

