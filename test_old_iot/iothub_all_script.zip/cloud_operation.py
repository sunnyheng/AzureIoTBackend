# coding: utf-8

#######################################################################################################################################
############################  The functionality logic, depends on received event from iot #############################################
#######################################################################################################################################


import time

from azure.core.exceptions import ResourceNotFoundError

from iot_hub_conn_info import IoTHubConnInfo
from blob_operation import BlobService
from iot_hub_cloud_service import IoTHubManager
from connction_string import BLOB_CONN_STR, SCENARIO_USER, SCENARIO_SQUARE
from iot_log import logger



def action_by_received(event):
    conn_obj = get_event_prop(event)
    iothub_client = IoTHubManager(conn_obj.conn_str)
    blob_service = BlobService(BLOB_CONN_STR)
    blob_client = blob_service.client
    # device_type
    event_data = event.body_as_json()
    event_data = event_data

    if isinstance(event_data, str):
        event_data.encode("utf-8")
        event_json = json.loads(event_data)
        logger.info("[iot] Uploaded message is string, already finished parsing to json")
    action = event_json.get("operation", None)
    if action == "ADD":
        update_data(conn_obj, iothub_client, blob_client, event_json)
    if action == "SYNC":
        # todo 哪端sync，给哪端发消息, 如果是刚联网，需要把上次delete 的id 也发送下去
        fetch_data(conn_obj, iothub_client, blob_client, event_json)

    if action == "DELETE":
        # 需要把云端数据删除，并把结果下发给两端
        delete_data(conn_obj, iothub_client, blob_client, event_json)


# this is add new data or update the existing data
def update_data(conn_obj, iothub_client, blob_client, event_json):
    # option 1. new json upload
    try:
        logger.info("[ADD]Start save data and send back to iot hub")
        save_str_to_blobs(blob_client, event_json)
    except Exception as be:
        logger.error("[ADD]Failed to save data to azure blob, more details:" + str(be))

    data_str = json.dumps(event_json)
    target_device_list = []
    if conn_obj.device_type == "car":
        target_device_list = conn_obj.phone_list
    if conn_obj.device_type == "phone":
        target_device_list = conn_obj.car_list
    try:
        for device_id in target_device_list:
            resp = iothub_client.get_device_info(device_id)
            check_device_status(resp, device_id)
            if resp.connection_state == "Connected":
                props = generate_props()
                try:
                    logger.info("[ADD]Send data:" + data_str)
                    iothub_client.iot_send_message(device_id, data_str, props)
                    logger.info("[ADD]Send c2d message to " + device_id+ " successfully")
                except Exception as se:
                    logger.error("[ADD]Failed to send c2d message(ADD) to " + device_id + ". More details:" + str(se))
                    print("[ADD]Failed to send c2d message(ADD) to " + device_id)
    except Exception as add_e:
        logger.error("[ADD]Failed to handle add scenario, more details:" + str(add_e))


def check_device_status(resp, device_id):
    if resp.connection_state == "Disconnected" and resp.cloud_to_device_message_count >= 20:
        count = iothub_client.purge_queue_message(device_id)
        print("The device: " + device_id + "is disconnected, and purge the queue message:"+ str(count))
        logger.info("The device: " + device_id + "is disconnected, and purge the queue message:"+ str(count))


def save_str_to_blobs(client, event_json):
    logger.info("[ADD]Start to save blob to azure")
    for key, value in event_json.items():
        # todo currently, no need to handle ScenarioSquare
        if key == "ScenarioUser":
            container_name = SCENARIO_USER
            parse_blob(client, container_name, value)


def parse_blob(client, container_name, str_val):
    if str_val:
        val_list = json.loads(str_val)
        if not isinstance(val_list, list):
            return
        for blob in val_list:
            file_name = str(blob.get('id'))
            logger.info("file_name:", file_name)
            client.save_data(container_name, file_name, json.dumps(blob))
            logger.info("[ADD] Finished to upload file:" + file_id)
            print("[ADD]Finished to upload file:" + file_id)


# the car/phone side SYNC data from cloud
def fetch_data(conn_obj, iothub_client, blob_client, event_json):
    # read date from blob and sent to iot
    blob = list_azure_blobs(blob_client)

    target_device_list = []
    if conn_obj.device_type == "car":
        target_device_list = conn_obj.car_list
    if conn_obj.device_type == "phone":
        target_device_list = conn_obj.phone_list
    logger.info("[SYNC]Get the c2d message device list:" + str(target_device_list))
    try:
        for device_id in target_device_list:
            resp = iothub_client.get_device_info(device_id)
            check_device_status(resp, device_id)
            if resp.connection_state == "Connected":
                # todo check the db, if it requires to send delete ids
                props = generate_props()
                try:
                    logger.info("[SYNC]Send c2d message:" + blob_str)
                    iothub_client.iot_send_message(device_id, blob_str, props)
                    logger.info("[SYNC]Send c2d message to " + device_id + " successfully")
                except Exception as se:
                    logger.error("[SYNC]Failed to send c2d message(SYNC) to " + device_id + ". More details:" + str(se))
                    print("[SYNC]Failed to send c2d message(SYNC) to " + device_id)
    except Exception as syc_e:
        logger.error("[SYNC]Failed to handle sync scenario, more details:" + str(syc_e))


def list_azure_blobs(blob_client):
    data = {}
    try:
        user_dict = blob_client.list_data(SCENARIO_USER, "ScenarioUser")
    except Exception as ue:
        logger.warning("[SYNC]Failed to get ScenarioUser data, more details:" + str(ue))
        user_dict = {}
    logger.info('[SYNC]ScenarioUser dict:' + str(user_dict))
    try:
        tmp_dict = blob_client.list_data(SCENARIO_SQUARE, "ScenarioSquare")
    except Exception as te:
        logger.warning("[SYNC]Failed to get ScenarioSquare data, more details:" + str(te))
        tmp_dict = {}
    logger.info('[SYNC]ScenarioSquare dict:' + str(tmp_dict))
    user_dict.update(tmp_dict)
    user_dict["operation"] = "SYNC"
    return user_dict


def delete_data(conn_obj, iothub_client, blob_client, event_json):
    # mark the data in target db/blob
    delete_resp = {}

    scenario_id_list = event_json.get('id')
    id_list_json = json.loads(scenario_id_list)
    container_name = SCENARIO_USER
    deleted_id_list = del_azure_blob(blob_client, id_list_json, container_name)

    if deleted_id_list:
        delete_resp["id"] = json.dumps(deleted_id_list)
        delete_resp["operation"] = "DELETE"
        delete_resp["ScenarioType"] = "ScenarioUser"
        message = json.dumps(delete_resp)
        logger.info("[Delete]Will send c2d delete message:" + message)

        # todo currently, only single phone and single car
        # if there are multiple cars, should check all of the device status,
        # if it is disconnected, it will be record in mongodb, when it sync data, it will receive the deleted data and sync data
        target_device_list = conn_obj.phone_list
        target_device_list.extend(conn_obj.car_list)
        logger.info("[Delete]Get the c2d message device list:" + str(target_device_list))

        for device_id in target_device_list:
            try:
                resp = iothub_client.get_device_info(device_id)
                if resp.connection_state == "Disconnected":
                    pass
                    #todo set to target database
                check_device_status(resp, device_id)
                if resp.connection_state == "Connected":
                    props = generate_props()
                    try:
                        logger.info("[DELETE]Send c2d message:" + blob_str)
                        iothub_client.iot_send_message(device_id, blob_str, props)
                        logger.info("[DELETE]Send c2d message to " + device_id + " successfully")
                    except Exception as se:
                        logger.error(
                            "[Delete]Failed to send c2d message(del) to " + device_id + ". More details:" + str(se))
                        print("[Delete]Failed to send c2d message(del) to " + device_id)
            except Exception as de:
                logger.error("[Delete]Failed get device infos, more details:" + str(de))


def del_azure_blob(blob_client, id_list, container_name):
    deleted_id = []
    for id in id_list:
        try:
            logger.info("[DELETE]Start delete the azure blob:" + str(id))
            blob_client.delete_data(container_name, str(id))
            deleted_id.append(str(id))
        except ResourceNotFoundError as ne:
            logger.warning("[DELETE]Not found the blob, maybe cache data in local(phone or car). Blob name:" + str(id))
            deleted_id.append(str(id))

        except Exception as e:
            print('[DELETE]Failed to delete azure blob:' + str(id))
            logger.error('[DELETE]Failed to delete azure blob:' + str(id) + ". More details:" + str(e))

    return deleted_id


def generate_props():
    stamp = (int(time.time()) + 500) * 1000
    props = {}
    props.update(expiryTimeUtc=stamp)
    props.update(contentType="application/json")
    return props


def get_event_prop(event):
    sys_props = event.system_properties
    device_id = sys_props.get("iothub-connection-device-id")
    # todo need the deviceType from car and phone side
    device_type = props.get("deviceType")
    # align user_id get from correlation_id
    user_id = event.correlation_id

    iothub_conn_info_obj = IoTHubConnInfo(user_id, device_type)
    iothub_conn_info_obj.create_client("127.0.0.1", 27017)
    iothub_conn_info_obj.parse_record()
    return iothub_conn_info_obj





